export class Assignment
{
  _id!:string;
  id!: number;
  nom!:string;
  dateDeRendu!:Date;
  matiere!:string;
  prof!:string;
  auteur!:string;
  note!:number;
  remarques!:[];
  rendu!:boolean;
}
